Generated lessons use no bundled demo media. This directory is required by the local renderer.
