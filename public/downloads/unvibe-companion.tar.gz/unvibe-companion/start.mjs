process.env.LEARNAGRAM_FRONTEND_URL ||= 'https://unvibe-learnagram.web.app/connect';
await import('./companion/index.mjs');
